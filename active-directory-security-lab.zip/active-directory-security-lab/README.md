# Enterprise Active Directory Security & File Server Hardening Lab

## Overview
This project demonstrates a secure Windows Server Active Directory domain environment with enterprise file server hardening, access control, and ransomware mitigation.

## Lab Setup
- SYS1: Domain Controller (Windows Server 2012)
- SYS2: Member Server + File Server
- Domain: local.com
- Virtualized using VMware

## Key Implementations
### Active Directory & IAM
- Department-based OUs (HR, Sales, IT)
- User and group management
- Role-based access control (RBAC)

### File Server Security
- Secure departmental shares
- NTFS permission isolation
- Centralized Home Folder deployment (Z: drive)

### Hardening & Protection
- Group Policy restrictions (USB block, CMD restriction, login banner)
- FSRM quotas + executable file screening (anti-ransomware)

## Screenshots
All proof screenshots are available in the `/screenshots` folder.

## Skills Demonstrated
Active Directory | Windows Server | Group Policy | NTFS | FSRM | Cybersecurity Hardening

## Author
Shaik Abubaker
